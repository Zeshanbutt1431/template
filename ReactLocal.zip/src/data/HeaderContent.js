	
			export const Logo =  	[
			{
				"id":1,
				"logopath": <img src="http://devspinup2-com.server-icumulusdedicated2-vps.vps.ezhostingserver.com/ccms/default/assets/Image/logo.svg" />,
			}
		]		

		
		
		export const Notification =  	[
			{ 
				"id":1,
				"desc": "Notification / Discount offer text goes here.",
			}
		]	
		
		
			export const HeaderBottomContent =[
				
			{
			
						"CompanyName":"Asterisk Solutions (Pvt) Ltd",
					
						"CompanyPhone":"+ (123) 456 678",
						
						"CompanyEmail":"info@firearmsshop.com",
						
						"Companyhours":"Working Hours: Mon - Fri: 9am to 6pm",
					
		}
			]				
	
