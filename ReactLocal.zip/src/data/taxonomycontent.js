
		export const navItems =  	[
		
			{
				"id":1,
				"DEPT": "OPTICS",
				"DEPTURL":"optics",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ACCESSORIES & TOOLS",
						"TYPURL":"optics-accessories-tools",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BINOCULARS",
						"TYPURL":"optics-binoculars", 
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "NIGHT VISION AND THERMAL",
						"TYPURL":"optics-nv-thermal",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "NIGHT VISION",
							"TYPURL":"optics-nv-thermal-night-vision",		
						}
						
					]
				
						
					}
					, 
					{
						"id":4,
						"TYPE": "OPTICS",
						"TYPURL":"optics-optics",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "RANGE FINDERS",
						"TYPURL":"optics-range-finders",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "RED DOT",
						"TYPURL":"optics-red-dot",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "SCOPES",
						"TYPURL":"optics-scopes",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "HANDGUN",
							"TYPURL":"optics-scopes-handgun",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "RIFLE",
							"TYPURL":"optics-scopes-rifle",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "SPOTTING",
							"TYPURL":"optics-scopes-spotting",		
						}
						
					]
				
						
					}
					, 
					{
						"id":8,
						"TYPE": "SIGHTS",
						"TYPURL":"optics-sights",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "LASER",
							"TYPURL":"optics-sights-laser",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "PISTOL",
							"TYPURL":"optics-sights-pistol",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "RIFLE",
							"TYPURL":"optics-sights-rifle",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "SHOTGUN",
							"TYPURL":"optics-sights-shotgun",		
						}
						
					]
				
						
					}
					
				]
				
			}
			, 
			{
				"id":2,
				"DEPT": "APPAREL",
				"DEPTURL":"apparel",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ACCESSORIES AND OTHER",
						"TYPURL":"apparel-accessories-and-other",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BASELAYER",
						"TYPURL":"apparel-baselayer",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "BELTS",
						"TYPURL":"apparel-belts",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "BOTTOMS",
						"TYPURL":"apparel-bottoms",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "FOOTWEAR",
						"TYPURL":"apparel-footwear",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "FOOTWEAR ACCESSORIES",
						"TYPURL":"apparel-footwear-accessories",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "GLOVES",
						"TYPURL":"apparel-gloves",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "HEADWEAR AND EYEWEAR",
						"TYPURL":"apparel-headwear-and-eyewear",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BEANIES",
							"TYPURL":"apparel-headwear-and-eyewear-beanies",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "CAPS & HATS",
							"TYPURL":"apparel-headwear-and-eyewear-caps-hats",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "MASKS",
							"TYPURL":"apparel-headwear-and-eyewear-masks",		
						}
						
					]
				
						
					}
					, 
					{
						"id":9,
						"TYPE": "HUNTING CLOTHING",
						"TYPURL":"apparel-hunting-clothing",
					
					
						
					}
					, 
					{
						"id":10,
						"TYPE": "LOAD BEARING EQUIPMENT",
						"TYPURL":"apparel-load-bearing-equipment",
					
					
						
					}
					, 
					{
						"id":11,
						"TYPE": "OUTERWEAR",
						"TYPURL":"apparel-outerwear",
					
					
						
					}
					, 
					{
						"id":12,
						"TYPE": "PERSONAL ACCESSORIES & NOVELTIES",
						"TYPURL":"apparel-personal-accessories-novelties",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "WALLETS",
							"TYPURL":"apparel-personal-accessories-novelties-wallets",		
						}
						
					]
				
						
					}
					, 
					{
						"id":13,
						"TYPE": "TOPS",
						"TYPURL":"apparel-tops",
					
					
						
					}
					, 
					{
						"id":14,
						"TYPE": "VESTS",
						"TYPURL":"apparel-vests",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":3,
				"DEPT": "ARCHERY",
				"DEPTURL":"archery",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ACCESSORIES",
						"TYPURL":"archery-accessories",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "TARGET ACCESSORIES",
							"TYPURL":"archery-accessories-target-accessories",		
						}
						
					]
				
						
					}
					, 
					{
						"id":2,
						"TYPE": "ARROWS",
						"TYPURL":"archery-arrows",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "BOWS AND CROSSBOWS",
						"TYPURL":"archery-bows-and-crossbows",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BROADHEADS",
							"TYPURL":"archery-bows-and-crossbows-broadheads",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "CROSSBOW BOLTS AND ARROWS",
							"TYPURL":"archery-bows-and-crossbows-crossbow-bolts-and-arrows",		
						}
						
					]
				
						
					}
					, 
					{
						"id":4,
						"TYPE": "CASES AND STORAGE",
						"TYPURL":"archery-cases-and-storage",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "CROSSBOW ACCESSORIES",
						"TYPURL":"archery-crossbow-accessories",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "COCKING DEVICES",
							"TYPURL":"archery-crossbow-accessories-cocking-devices",		
						}
						
					]
				
						
					}
					, 
					{
						"id":6,
						"TYPE": "FLETCHING TOOLS AND MATERIALS",
						"TYPURL":"archery-fletching-tools-and-materials",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "SIGHTS",
						"TYPURL":"archery-sights",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "STRING ACCESSORIES",
						"TYPURL":"archery-string-accessories",
					
					
						
					}
					, 
					{
						"id":9,
						"TYPE": "TARGETS",
						"TYPURL":"archery-targets",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":4,
				"DEPT": "DUTY GEAR",
				"DEPTURL":"duty-gear",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "BATONS",
						"TYPURL":"duty-gear-batons",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BODY ARMOR PROTECTION",
						"TYPURL":"duty-gear-body-armor-protection",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "ELECTRONICS COMMUNICATION",
						"TYPURL":"duty-gear-electronics-communication",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "FIRST AID",
						"TYPURL":"duty-gear-first-aid",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "HOLSTERS",
						"TYPURL":"duty-gear-holsters",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "LIGHTS",
						"TYPURL":"duty-gear-lights",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "RESTRAINTS",
						"TYPURL":"duty-gear-restraints",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "TRAINING DEFENSE",
						"TYPURL":"duty-gear-training-defense",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":5,
				"DEPT": "FIREARMS",
				"DEPTURL":"firearms",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "BLACK POWDER",
						"TYPURL":"firearms-black-powder",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "COMBO",
						"TYPURL":"firearms-combo",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "HANDGUNS",
						"TYPURL":"firearms-handguns",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BLANK GUNS",
							"TYPURL":"firearms-handguns-blank-guns",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "PISTOLS",
							"TYPURL":"firearms-handguns-pistols",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "REVOLVERS",
							"TYPURL":"firearms-handguns-revolvers",		
						}
						
					]
				
						
					}
					, 
					{
						"id":4,
						"TYPE": "NFA",
						"TYPURL":"firearms-nfa",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "SHORT BARRELED RIFLES",
							"TYPURL":"firearms-nfa-short-barreled-rifles",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "SHORT BARRELED SHOTGUNS",
							"TYPURL":"firearms-nfa-short-barreled-shotguns",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "SUPPRESSORS",
							"TYPURL":"firearms-nfa-silencers",		
						}
						
					]
				
						
					}
					, 
					{
						"id":5,
						"TYPE": "RECEIVERS & FRAMES",
						"TYPURL":"firearms-receivers",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "FRAMES",
							"TYPURL":"firearms-receivers-frames",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "LOWERS",
							"TYPURL":"firearms-receivers-lowers",		
						}
						
					]
				
						
					}
					, 
					{
						"id":6,
						"TYPE": "REVOLVERS",
						"TYPURL":"firearms-revolvers",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "RIFLES",
						"TYPURL":"firearms-rifles",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "ACTION",
							"TYPURL":"firearms-rifles-action",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "BOLT-ACTION",
							"TYPURL":"firearms-rifles-bolt-action",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "CENTERFIRE",
							"TYPURL":"firearms-rifles-centerfire",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "LEVER-ACTION",
							"TYPURL":"firearms-rifles-lever-action",		
						}
						, 
						{
							"id":5,
							"SUBTYPE": "OTHER",
							"TYPURL":"firearms-rifles-other",		
						}
						, 
						{
							"id":6,
							"SUBTYPE": "PUMP",
							"TYPURL":"firearms-rifles-pump",		
						}
						, 
						{
							"id":7,
							"SUBTYPE": "RIMFIRE",
							"TYPURL":"firearms-rifles-rimfire",		
						}
						, 
						{
							"id":8,
							"SUBTYPE": "SEMI-AUTO",
							"TYPURL":"firearms-rifles-semi-auto",		
						}
						, 
						{
							"id":9,
							"SUBTYPE": "SINGLE-SHOT",
							"TYPURL":"firearms-rifles-single-shot",		
						}
						, 
						{
							"id":10,
							"SUBTYPE": "TACTICAL",
							"TYPURL":"firearms-rifles-tactical-rifles",		
						}
						
					]
				
						
					}
					, 
					{
						"id":8,
						"TYPE": "SHOTGUNS",
						"TYPURL":"firearms-shotguns",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "ACTION",
							"TYPURL":"firearms-shotguns-action",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "OTHER",
							"TYPURL":"firearms-shotguns-other",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "OVER UNDER",
							"TYPURL":"firearms-shotguns-over-under",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "PUMP ACTION",
							"TYPURL":"firearms-shotguns-pump",		
						}
						, 
						{
							"id":5,
							"SUBTYPE": "SEMI AUTO",
							"TYPURL":"firearms-shotguns-semi-auto",		
						}
						, 
						{
							"id":6,
							"SUBTYPE": "SIDE BY SIDE",
							"TYPURL":"firearms-shotguns-side-by-side",		
						}
						, 
						{
							"id":7,
							"SUBTYPE": "SINGLE BARREL",
							"TYPURL":"firearms-shotguns-single-barrel",		
						}
						, 
						{
							"id":8,
							"SUBTYPE": "SINGLE SHOT AND BOLT",
							"TYPURL":"firearms-shotguns-single-shot-and-bolt",		
						}
						, 
						{
							"id":9,
							"SUBTYPE": "TACTICAL",
							"TYPURL":"firearms-shotguns-tactical",		
						}
						
					]
				
						
					}
					
				]
				
			}
			, 
			{
				"id":6,
				"DEPT": "AMMUNITION",
				"DEPTURL":"ammunition",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "BLACK POWDER",
						"TYPURL":"ammunition-black-powder",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BLANKS/SLUGS",
						"TYPURL":"ammunition-blanks-slugs",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "PISTOL",
						"TYPURL":"ammunition-pistol",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "RIFLE",
						"TYPURL":"ammunition-rifle",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "HUNTING",
							"TYPURL":"ammunition-rifle-hunting",		
						}
						
					]
				
						
					}
					, 
					{
						"id":5,
						"TYPE": "RIMFIRE",
						"TYPURL":"ammunition-rimfire",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "SHOTSHELL",
						"TYPURL":"ammunition-shotshell",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BIRDSHOT",
							"TYPURL":"ammunition-shotshell-birdshot",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "BUCKSHOT",
							"TYPURL":"ammunition-shotshell-buckshot",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "SLUG",
							"TYPURL":"ammunition-shotshell-slug",		
						}
						
					]
				
						
					}
					, 
					{
						"id":7,
						"TYPE": "SNAP CAPS",
						"TYPURL":"ammunition-snap-caps",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":7,
				"DEPT": "GUN PARTS",
				"DEPTURL":"gun-parts",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ACCESSORIES",
						"TYPURL":"gun-parts-accessories",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "AR PARTS",
						"TYPURL":"gun-parts-ar-parts",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "BARRELS",
						"TYPURL":"gun-parts-barrels",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "BIPODS AND RESTS",
						"TYPURL":"gun-parts-bipods-rests",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "BOLTS",
						"TYPURL":"gun-parts-bolts",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "CHOKES",
						"TYPURL":"gun-parts-chokes",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "COMPLETE UPPERS",
						"TYPURL":"gun-parts-complete-uppers",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "CONVERSION KITS",
						"TYPURL":"gun-parts-conversion-kits",
					
					
						
					}
					, 
					{
						"id":9,
						"TYPE": "FRAMES AND CHASSIS",
						"TYPURL":"gun-parts-frames-chassis",
					
					
						
					}
					, 
					{
						"id":10,
						"TYPE": "GRIPS",
						"TYPURL":"gun-parts-grips",
					
					
						
					}
					, 
					{
						"id":11,
						"TYPE": "GUNSMITHING",
						"TYPURL":"gun-parts-gunsmithing",
					
					
						
					}
					, 
					{
						"id":12,
						"TYPE": "HANDGUN",
						"TYPURL":"gun-parts-handgun",
					
					
						
					}
					, 
					{
						"id":13,
						"TYPE": "HARDWARE",
						"TYPURL":"gun-parts-hardware",
					
					
						
					}
					, 
					{
						"id":14,
						"TYPE": "LONG GUNS",
						"TYPURL":"gun-parts-long-gun",
					
					
						
					}
					, 
					{
						"id":15,
						"TYPE": "MAGAZINES",
						"TYPURL":"gun-parts-magazines",
					
					
						
					}
					, 
					{
						"id":16,
						"TYPE": "MUZZLE DEVICES",
						"TYPURL":"gun-parts-muzzle-devices",
					
					
						
					}
					, 
					{
						"id":17,
						"TYPE": "OTHER",
						"TYPURL":"gun-parts-other",
					
					
						
					}
					, 
					{
						"id":18,
						"TYPE": "RAILS",
						"TYPURL":"gun-parts-rails",
					
					
						
					}
					, 
					{
						"id":19,
						"TYPE": "RECOIL PADS",
						"TYPURL":"gun-parts-recoil-pads",
					
					
						
					}
					, 
					{
						"id":20,
						"TYPE": "SLIDES",
						"TYPURL":"gun-parts-slides",
					
					
						
					}
					, 
					{
						"id":21,
						"TYPE": "SLINGS AND SWIVELS",
						"TYPURL":"gun-parts-slings-and-swivels",
					
					
						
					}
					, 
					{
						"id":22,
						"TYPE": "STOCKS",
						"TYPURL":"gun-parts-stocks",
					
					
						
					}
					, 
					{
						"id":23,
						"TYPE": "TOOLS",
						"TYPURL":"gun-parts-tools",
					
					
						
					}
					, 
					{
						"id":24,
						"TYPE": "TRIGGERS",
						"TYPURL":"gun-parts-triggers",
					
					
						
					}
					, 
					{
						"id":25,
						"TYPE": "UPPERS",
						"TYPURL":"gun-parts-uppers",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":8,
				"DEPT": "CLEANING & STORAGE",
				"DEPTURL":"cleaning-storage",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "BACKPACKS AND PACKS",
						"TYPURL":"cleaning-storage-backpacks-and-packs",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "CASES",
						"TYPURL":"cleaning-storage-cases",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "AMMO BOXES",
							"TYPURL":"cleaning-storage-cases-ammo-boxes",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "ARCHERY CASES",
							"TYPURL":"cleaning-storage-cases-archery-cases",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "HANDGUN CASES",
							"TYPURL":"cleaning-storage-cases-handgun-cases",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "HARD",
							"TYPURL":"cleaning-storage-cases-hard",		
						}
						, 
						{
							"id":5,
							"SUBTYPE": "MULTI-PURPOSE BAGS",
							"TYPURL":"cleaning-storage-cases-multi-purpose-bags",		
						}
						, 
						{
							"id":6,
							"SUBTYPE": "OTHER",
							"TYPURL":"cleaning-storage-cases-other",		
						}
						, 
						{
							"id":7,
							"SUBTYPE": "RIFLE CASES",
							"TYPURL":"cleaning-storage-cases-rifle-cases",		
						}
						, 
						{
							"id":8,
							"SUBTYPE": "SHOTGUN CASES",
							"TYPURL":"cleaning-storage-cases-shotgun-cases",		
						}
						
					]
				
						
					}
					, 
					{
						"id":3,
						"TYPE": "CLEANING",
						"TYPURL":"cleaning-storage-cleaning",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BARREL CLEANING",
							"TYPURL":"cleaning-storage-cleaning-barrel-cleaning",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "CLEANING KITS",
							"TYPURL":"cleaning-storage-cleaning-cleaning-kits",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "CLEANING SOLVENTS AND LUBRICANTS",
							"TYPURL":"cleaning-storage-cleaning-cleaning-solvents-lubricants",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "CLEANING STANDS",
							"TYPURL":"cleaning-storage-cleaning-cleaning-stands",		
						}
						, 
						{
							"id":5,
							"SUBTYPE": "CLEANING SUPPLIES",
							"TYPURL":"cleaning-storage-cleaning-other-cleaning-supplies",		
						}
						
					]
				
						
					}
					, 
					{
						"id":4,
						"TYPE": "RANGE PACKS",
						"TYPURL":"cleaning-storage-range-packs",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "SAFES AND VAULTS",
						"TYPURL":"cleaning-storage-safes-vaults",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "SAFE ACCESSORIES",
							"TYPURL":"cleaning-storage-safes-vaults-safe-accessories",		
						}
						
					]
				
						
					}
					
				]
				
			}
			, 
			{
				"id":9,
				"DEPT": "CAMPING & OUTDOOR",
				"DEPTURL":"camping-outdoor",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ACCESSORIES",
						"TYPURL":"camping-outdoor-accessories",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BACKPACKS & GEARBAGS & BAGS",
						"TYPURL":"camping-outdoor-backpacks-and-gearbags-and-bags",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BAG",
							"TYPURL":"camping-outdoor-backpacks-and-gearbags-and-bags-bag",		
						}
						
					]
				
						
					}
					, 
					{
						"id":3,
						"TYPE": "CAMPING",
						"TYPURL":"camping-outdoor-camping",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "COOKING",
						"TYPURL":"camping-outdoor-cooking",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "UTENSILS",
							"TYPURL":"camping-outdoor-cooking-utensils",		
						}
						
					]
				
						
					}
					, 
					{
						"id":5,
						"TYPE": "COOLERS-DRINKWARE",
						"TYPURL":"camping-outdoor-coolers-drinkware",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "FOOD AND FOOD STORAGE",
						"TYPURL":"camping-outdoor-food-and-food-storage",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "FURNITURE",
						"TYPURL":"camping-outdoor-furniture",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "HEALTH AND OUTDOOR",
						"TYPURL":"camping-outdoor-health-outdoor",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "FIRST AID",
							"TYPURL":"camping-outdoor-health-outdoor-first-aid",		
						}
						
					]
				
						
					}
					, 
					{
						"id":9,
						"TYPE": "HYDRATION SYSTEMS",
						"TYPURL":"camping-outdoor-hydration-systems",
					
					
						
					}
					, 
					{
						"id":10,
						"TYPE": "PERSONAL DEFENSE",
						"TYPURL":"camping-outdoor-personal-defense",
					
					
						
					}
					, 
					{
						"id":11,
						"TYPE": "SURVIVAL",
						"TYPURL":"camping-outdoor-survival",
					
					
						
					}
					, 
					{
						"id":12,
						"TYPE": "TOOLS AND EQUIPMENT",
						"TYPURL":"camping-outdoor-tools-and-equipment",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":10,
				"DEPT": "KNIVES AND TOOLS",
				"DEPTURL":"knives-and-tools",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "ASSISTED OPENING",
						"TYPURL":"knives-and-tools-assisted-opening",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "AUTOMATICS",
						"TYPURL":"knives-and-tools-automatics",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "AXES AND HATCHETS",
						"TYPURL":"knives-and-tools-axes-and-hatches",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "FIXED",
						"TYPURL":"knives-and-tools-fixed",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "FOLDING",
						"TYPURL":"knives-and-tools-folding",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "KNIVES AND TOOLS",
						"TYPURL":"knives-and-tools-knives-tools",
					
					
						
					}
					, 
					{
						"id":7,
						"TYPE": "MACHETES",
						"TYPURL":"knives-and-tools-machetes",
					
					
						
					}
					, 
					{
						"id":8,
						"TYPE": "MULTI-TOOLS",
						"TYPURL":"knives-and-tools-multi-tools",
					
					
						
					}
					, 
					{
						"id":9,
						"TYPE": "SAWS",
						"TYPURL":"knives-and-tools-saws",
					
					
						
					}
					, 
					{
						"id":10,
						"TYPE": "SHARPENERS AND ACCESSORIES",
						"TYPURL":"knives-and-tools-sharpeners-and-accessories",
					
					
						
					}
					, 
					{
						"id":11,
						"TYPE": "SHOVELS",
						"TYPURL":"knives-and-tools-shovels",
					
					
						
					}
					, 
					{
						"id":12,
						"TYPE": "SWORDS AND ACCESSORIES",
						"TYPURL":"knives-and-tools-swords-and-accessories",
					
					
						
					}
					, 
					{
						"id":13,
						"TYPE": "THROWING",
						"TYPURL":"knives-and-tools-throwing",
					
					
						
					}
					, 
					{
						"id":14,
						"TYPE": "TOOLS AND EQUIPMENT",
						"TYPURL":"knives-and-tools-other-blades-accessories",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":11,
				"DEPT": "GIFTS & NOVELTY",
				"DEPTURL":"gifts-and-novelty",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "HOME",
						"TYPURL":"gifts-and-novelty-home",
					
					
						
					}
					
				]
				
			}
			, 
			{
				"id":12,
				"DEPT": "ACCESSORIES",
				"DEPTURL":"accessories",
			
								
				Type:[
				
					{
						"id":1,
						"TYPE": "AUGER",
						"TYPURL":"accessories-auger",
					
					
						
					}
					, 
					{
						"id":2,
						"TYPE": "BLACK POWDER",
						"TYPURL":"accessories-black-powder",
					
					
						
					}
					, 
					{
						"id":3,
						"TYPE": "BOOKS AND VIDEOS",
						"TYPURL":"accessories-books-and-videos",
					
					
						
					}
					, 
					{
						"id":4,
						"TYPE": "BORE SIGHTER/BRUSHES",
						"TYPURL":"accessories-bore-sighter-brushes",
					
					
						
					}
					, 
					{
						"id":5,
						"TYPE": "DISPLAY",
						"TYPURL":"accessories-display",
					
					
						
					}
					, 
					{
						"id":6,
						"TYPE": "ELECTRONICS",
						"TYPURL":"accessories-electronics",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "CAMERA ACCESSORIES",
							"TYPURL":"accessories-electronics-camera-accessories",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "CAMERAS",
							"TYPURL":"accessories-electronics-cameras",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "CHARGERS",
							"TYPURL":"accessories-electronics-chargers",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "RADIO",
							"TYPURL":"accessories-electronics-radio",		
						}
						
					]
				
						
					}
					, 
					{
						"id":7,
						"TYPE": "FIREARM ACCESSORIES",
						"TYPURL":"accessories-firearm-accessories",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "BIPODS MONOPODS TRIPODS",
							"TYPURL":"accessories-firearm-accessories-bipods-monopods-tripods",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "BRACES",
							"TYPURL":"accessories-firearm-accessories-braces",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "HANDGAURDS AND QUAD RAILS",
							"TYPURL":"accessories-firearm-accessories-handgaurds-and-quad-rails",		
						}
						, 
						{
							"id":4,
							"SUBTYPE": "LIGHTS",
							"TYPURL":"accessories-firearm-accessories-lights",		
						}
						, 
						{
							"id":5,
							"SUBTYPE": "MOUNTS",
							"TYPURL":"accessories-firearm-accessories-mounts",		
						}
						, 
						{
							"id":6,
							"SUBTYPE": "NFA",
							"TYPURL":"accessories-firearm-accessories-nfa",		
						}
						, 
						{
							"id":7,
							"SUBTYPE": "RAILS AND BASES",
							"TYPURL":"accessories-firearm-accessories-rails-bases",		
						}
						, 
						{
							"id":8,
							"SUBTYPE": "SPEEDLOADERS",
							"TYPURL":"accessories-firearm-accessories-speedloaders",		
						}
						, 
						{
							"id":9,
							"SUBTYPE": "SUPPRESSOR ACCESSORIES",
							"TYPURL":"accessories-firearm-accessories-suppressor-accessories",		
						}
						
					]
				
						
					}
					, 
					{
						"id":8,
						"TYPE": "HOLSTERS",
						"TYPURL":"accessories-holsters",
					
					
						
					}
					, 
					{
						"id":9,
						"TYPE": "LIGHTS LASERS BATTERIES",
						"TYPURL":"accessories-lights-lasers-batteries",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "SPOTLIGHT",
							"TYPURL":"accessories-lights-lasers-batteries-spotlight",		
						}
						
					]
				
						
					}
					, 
					{
						"id":10,
						"TYPE": "MAGAZINES",
						"TYPURL":"accessories-magazines",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "MAGAZINE ACCESSORIES",
							"TYPURL":"accessories-magazines-magazine-accessories",		
						}
						, 
						{
							"id":2,
							"SUBTYPE": "MAGAZINE LOADERS",
							"TYPURL":"accessories-magazines-magazine-loaders",		
						}
						, 
						{
							"id":3,
							"SUBTYPE": "SPEEDLOADERS",
							"TYPURL":"accessories-magazines-speedloaders",		
						}
						
					]
				
						
					}
					, 
					{
						"id":11,
						"TYPE": "OTHER",
						"TYPURL":"accessories-other",
					
					
					SubType:[
					
						{
							"id":1,
							"SUBTYPE": "SLING SHOTS AND ACCESSORIES",
							"TYPURL":"accessories-other-sling-shots-accessories",		
						}
						
					]
				
						
					}
					, 
					{
						"id":12,
						"TYPE": "SHOOTING AIDS & WIND METERS",
						"TYPURL":"accessories-shooting-aids-wind-meters",
					
					
						
					}
					
				]
				
			}
			
		]
		
	
