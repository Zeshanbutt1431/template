
import { Link } from 'react-router-dom';
export const minibanners =[

	{
		
			"id":1,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb1.png" />,
				
					"Heading":"Pistols",
				
					"URL":"/c/ammunition",
				
	}
	, 
	{
		
			"id":2,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb2.png" />,
				
					"Heading":"Rifles",
				
					"URL":"/c/ammunition",
				
	}
	, 
	{
		
			"id":3,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb3.png" />,
				
					"Heading":"Ammunition",
				
					"URL":"/c/ammunition",
				
	}
	, 
	{
		
			"id":4,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb4.png" />,
				
					"Heading":"Bags &amp; Vests",
				
					"URL":"/c/ammunition",
				
	}
	, 
	{
		
			"id":5,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb5.png" />,
				
					"Heading":"Scopes",
				
					"URL":"/c/ammunition",
				
	}
	, 
	{
		
			"id":6,
		
					"img": <img alt="" src="/ccms/default/assets/Image/mb6.png" />,
				
					"Heading":"Range &amp; Classes",
				
					"URL":"/c/ammunition",
				
	}
	
]		

