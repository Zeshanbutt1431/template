
import { Link } from 'react-router-dom';
export const deals2 =[

	{
		
			"id":1,
		
					"img": <img alt="" src="/ccms/default/assets/Image/d3.png" />,
				
					"Heading":"BEST DEALS ON HUNTING GEARS",						
				
	}
	, 
	{
		
			"id":2,
		
					"img": <img alt="" src="/ccms/default/assets/Image/d4.png" />,
				
					"Heading":"30% DISCOUNT ON GUNSMITHING",						
				
	}
	
]		

