
import { Link } from 'react-router-dom';
export const sliders =[

	{
		
			"id":1,
		
					"img": <img alt="" src="/ccms/default/assets/Image/Slider1.png" />,
				
					"Heading":"Heading Goes Here",
				
					"SubHeading":"Subheading Goes here",
				
					"desc":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque laudantium deleniti quasi voluptates ullam reprehenderit maiores iure nobis reiciendis vero accusamus omnis eos, provident tempore temporibus nemo quia. Nulla, unde.",
				
					"ShopNow":"/c/firearms",
				
	}
	, 
	{
		
			"id":2,
		
					"img": <img alt="" src="/ccms/default/assets/Image/Slider2.png" />,
				
					"Heading":"Heading Goes Here",
				
					"SubHeading":"Subheading Goes here",
				
					"desc":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque laudantium deleniti quasi voluptates ullam reprehenderit maiores iure nobis reiciendis vero accusamus omnis eos, provident tempore temporibus nemo quia. Nulla, unde.",
				
					"ShopNow":"/c/firearms",
				
	}
	, 
	{
		
			"id":3,
		
					"img": <img alt="" src="/ccms/default/assets/Image/Slider3.png" />,
				
					"Heading":"Heading Goes Here",
				
					"SubHeading":"Subheading Goes here",
				
					"desc":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque laudantium deleniti quasi voluptates ullam reprehenderit maiores iure nobis reiciendis vero accusamus omnis eos, provident tempore temporibus nemo quia. Nulla, unde.",
				
					"ShopNow":"/c/firearms",
				
	}
	
]		

