export const services = 
[
	{
		"id":1,
		"img": <img alt="logo" src="assets/images/logo.svg" />,
		"phone": "+(123) 456 789",	
		"Description1": "HUSTLE FREE RETURNS",	
		"Description2": "LOW SHIPPING RATES",	
	}
]