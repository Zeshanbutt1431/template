
		export const footer =  	[
		
			{
				"id":1,
				"heading": "Information",
			
				
				menu:[
				
					{
						"id":1,
						"LINKTITLE": "Template Settings",
						"URL":"/info/template-settings",
					}
					, 
					{
						"id":2,
						"LINKTITLE": "Search Terms",
						"URL":"/info/search-terms",
					}
					, 
					{
						"id":3,
						"LINKTITLE": "Privacy Policy",
						"URL":"/info/privacypolicy",
					}
					, 
					{
						"id":4,
						"LINKTITLE": "About Us",
						"URL":"/info/aboutus",
					}
					, 
					{
						"id":5,
						"LINKTITLE": "Advandaced Search",
						"URL":"/info/advandaced-search",
					}
					, 
					{
						"id":6,
						"LINKTITLE": "Orders and Returns",
						"URL":"/info/orders-and-returns",
					}
					, 
					{
						"id":7,
						"LINKTITLE": "Customer Services",
						"URL":"/info/customer-services",
					}
					, 
					{
						"id":8,
						"LINKTITLE": "Contact us",
						"URL":"/info/contactus",
					}
					
				]				
			}
			, 
			{
				"id":2,
				"heading": "Why buy from us",
			
				
				menu:[
				
					{
						"id":1,
						"LINKTITLE": "Shipping and Delivery",
						"URL":"/info/shipping-and-delivery",
					}
					, 
					{
						"id":2,
						"LINKTITLE": "Secure Payments",
						"URL":"/info/secure-payments",
					}
					, 
					{
						"id":3,
						"LINKTITLE": "Support",
						"URL":"/info/support",
					}
					, 
					{
						"id":4,
						"LINKTITLE": "Gurantee",
						"URL":"/info/gurantee",
					}
					, 
					{
						"id":5,
						"LINKTITLE": "Terms and Conditions",
						"URL":"/info/TermsandConditions",
					}
					
				]				
			}
			, 
			{
				"id":3,
				"heading": "My Account",
			
				
				menu:[
				
					{
						"id":1,
						"LINKTITLE": "Sign In",
						"URL":"/login.cfm",
					}
					, 
					{
						"id":2,
						"LINKTITLE": "View Cart",
						"URL":"/cart.cfm",
					}
					, 
					{
						"id":3,
						"LINKTITLE": "My Wishlist",
						"URL":"/wishlist.cfm",
					}
					, 
					{
						"id":4,
						"LINKTITLE": "FAQ",
						"URL":"/info/faq",
					}
					
				]				
			}
			
		]
		
	
