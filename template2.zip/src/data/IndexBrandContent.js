
import {Link} from 'react-router-dom'
export const indexbrands = [

	{
		"id":1,
		"img": <Link to='/b/barret'><img alt="Berret" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Barret.jpg" /></Link>,	
	}
	, 
	{
		"id":2,
		"img": <Link to='/b/glock'><img alt="Brand Glock" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Glock.jpg" /></Link>,	
	}
	, 
	{
		"id":3,
		"img": <Link to='/b/heckler and koch'><img alt="HK" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/HK.jpg" /></Link>,	
	}
	, 
	{
		"id":4,
		"img": <Link to='/b/mossberg'><img alt="Brand Mossberg" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Mossberg.jpg" /></Link>,	
	}
	, 
	{
		"id":5,
		"img": <Link to='/b/rock%20island'><img alt="Brand Rock Island" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/rock%20island.jpg" /></Link>,	
	}
	, 
	{
		"id":6,
		"img": <Link to='/b/ruger'><img alt="Brand Ruger" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Ruger.jpg" /></Link>,	
	}
	, 
	{
		"id":7,
		"img": <Link to='/b/savage'><img alt="Brand Savage" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Savage.jpg" /></Link>,	
	}
	, 
	{
		"id":8,
		"img": <Link to='/b/smith and wesson'><img alt="Brand Glock" class="img-fluid" src="/ccms/default/assets/Image/Template%20II/Smith%20%26%20Winson.jpg" /></Link>,	
	}
	
]		

