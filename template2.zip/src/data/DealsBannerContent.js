
import { Link } from 'react-router-dom';
export const deals =[

	{
		
			"id":1,
		
					"img": <img alt="" src="/ccms/default/assets/Image/d1.png" />,
				
					"Heading":"AVAILABLE ONLINE UP TO 43% OFF",
				
					"Logo":<img alt="" src="/ccms/default/assets/Image/ss.png" />,
				
	}
	, 
	{
		
			"id":2,
		
					"img": <img alt="" src="/ccms/default/assets/Image/d2.png" />,
				
					"Heading":"BEST DEALS ON OPTICS",
				
					"Logo":<img alt="" src="/ccms/default/assets/Image/vo.png" />,
				
	}
	
]		

