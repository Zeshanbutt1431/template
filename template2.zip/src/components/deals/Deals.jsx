import './Deals.css';
import { deals } from '../../data/DealsBannerContent'
import { Col, Row } from 'react-bootstrap';
const Deals = () => {
    return (
        <div className="deals-container">

        <Row className='deals'>
            {deals.map((deal,index) => (
                <Col md={12} className="banner">
                    <div className="banner-image">
                        {deal.img}
                        <div className="deal-overlay"></div>
                    </div>
                    <div className="banner-content">
                        {deal.Logo}
                        <h1>{deal.Heading}</h1>
                    </div>
                </Col>
            ))}

        </Row>
        </div>
    )
}

export default Deals