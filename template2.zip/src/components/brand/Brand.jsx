import './Brand.css'

const Brand = ({brand}) => {
	return (
		<>
			<div className='brand link'>
				{brand.img}
			</div>
		</>
	)
}

export default Brand